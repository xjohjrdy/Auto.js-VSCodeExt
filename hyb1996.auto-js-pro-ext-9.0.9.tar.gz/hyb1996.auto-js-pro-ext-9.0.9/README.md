# Auto.js-Pro-Ext README

教程和信息参见：https://blog.autojs.org/2022/10/15/vscode-debug-v9/

Auto.js Pro下载：https://pro.autojs.org/
