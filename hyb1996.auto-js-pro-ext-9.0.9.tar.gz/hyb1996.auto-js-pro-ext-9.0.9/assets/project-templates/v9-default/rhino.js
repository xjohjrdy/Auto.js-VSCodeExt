"rhino";
// 本文件以rhino引擎(第一代API)模式运行
// This file runs in rhino engine (API v1) mode

toastLog("Hello, World");
