toastLog('Hello, Auto.js ' + $app.autojs.versionName);
